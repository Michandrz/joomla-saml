<?php

/**
 * @package     OneLogin SAML.Component
 * @subpackage  oneloginsaml
 *
 * @copyright   Copyright (C) 2019 OneLogin, Inc. All rights reserved.
 * @license     MIT 
 */
defined('_JEXEC') or die;
/**
 * 
 */
class oneloginsamlController extends JControllerLegacy {
    
    /**
     * The default view
     * @var string
     */
     protected $default_View = "oneloginsaml";
     
}
