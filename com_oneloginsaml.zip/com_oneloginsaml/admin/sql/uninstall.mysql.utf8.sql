/** 
 * @package     OneLogin SAML
 * @subpackage  
 * 
 * @copyright   Copyright (C) 2019 OneLogin, Inc. All rights reserved.
 * @license     MIT
 * @author Michael Andrzejewski
 */

DROP TABLE IF EXISTS `#__oneloginsaml_config`;
DROP TABLE IF EXISTS `#__oneloginsaml_attrmap`;
DROP TABLE IF EXISTS `#__oneloginsaml_groupmap`;