<?php
/** 
 * @package     OneLogin SAML
 * @subpackage  com_oneloginsaml
 * 
 * @copyright   Copyright (C) 2019 OneLogin, Inc. All rights reserved.
 * @license     MIT
 * @author Michael Andrzejewski<michael@jetskitechnologies.com>
 */
defined('_JEXEC') or die('Restricted access');

/**
 * Standard Joomla view class
 * 
 * @since 1.7.0
 */
class oneloginsamlViewOneloginsaml extends Joomla\CMS\MVC\View\HtmlView {
}
